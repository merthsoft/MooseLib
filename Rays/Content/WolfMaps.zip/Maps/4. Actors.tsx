<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Actors" tilewidth="16" tileheight="16" tilecount="12" columns="4">
 <image source="../Images/Actors.png" width="64" height="48"/>
</tileset>
