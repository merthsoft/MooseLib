<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Doors" tilewidth="16" tileheight="16" tilecount="10" columns="10">
 <image source="../Images/Doors.png" width="160" height="16"/>
</tileset>
