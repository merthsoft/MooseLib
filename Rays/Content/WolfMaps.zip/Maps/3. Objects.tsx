<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Objects" tilewidth="16" tileheight="16" tilecount="55" columns="55">
 <image source="../Images/Objects.png" width="880" height="16"/>
</tileset>
