<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Walls" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <image source="../Images/Walls.png" width="896" height="16"/>
</tileset>
