<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Special" tilewidth="16" tileheight="16" tilecount="10" columns="5">
 <image source="../Images/Special.png" width="80" height="32"/>
</tileset>
